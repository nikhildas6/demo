import { NeuralNetwork } from './components/NeuralNetwork';
import { Navbar } from './components/Navbar';
import { HeroSection } from './sections/HeroSection';
import { ProblemSection } from './sections/ProblemSection';
import { ServicesSection } from './sections/ServicesSection';
import { ProcessSection } from './sections/ProcessSection';
import { PortfolioSection } from './sections/PortfolioSection';
import { ContactSection } from './sections/ContactSection';
import { Footer } from './sections/Footer';

function App() {
  return (
    <div className="relative min-h-screen">
      {/* Background Effects */}
      <div className="background-effects">
        <NeuralNetwork />
        <div className="absolute w-1 h-1 bg-[#00f3ff] rounded-full shadow-[0_0_10px_#00f3ff] animate-float" 
          style={{ top: '20%', left: '10%', animationDelay: '0s' }} 
        />
        <div className="absolute w-1 h-1 bg-[#00f3ff] rounded-full shadow-[0_0_10px_#00f3ff] animate-float" 
          style={{ top: '60%', left: '80%', animationDelay: '2s' }} 
        />
        <div className="absolute w-1 h-1 bg-[#64ffda] rounded-full shadow-[0_0_10px_#64ffda] animate-float" 
          style={{ top: '40%', left: '90%', animationDelay: '4s' }} 
        />
      </div>

      {/* Navigation */}
      <Navbar />

      {/* Main Content */}
      <main className="relative z-10">
        <HeroSection />
        <ProblemSection />
        <ServicesSection />
        <ProcessSection />
        <PortfolioSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;
