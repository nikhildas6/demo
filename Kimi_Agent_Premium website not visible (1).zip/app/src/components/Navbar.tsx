import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 w-full px-[5%] py-5 flex justify-between items-center z-50 transition-all duration-300 ${
        isScrolled ? 'glass-panel' : 'bg-transparent'
      }`}
    >
      <div className="text-2xl font-bold tracking-wider">
        WHITECAP <span className="text-[#00f3ff]">AI</span>
      </div>

      {/* Desktop Navigation */}
      <ul className="hidden md:flex items-center gap-8 list-none">
        <li>
          <button
            onClick={() => scrollToSection('services')}
            className="text-[#e6f1ff] text-[0.95rem] hover:text-[#00f3ff] transition-colors"
          >
            Services
          </button>
        </li>
        <li>
          <button
            onClick={() => scrollToSection('process')}
            className="text-[#e6f1ff] text-[0.95rem] hover:text-[#00f3ff] transition-colors"
          >
            Process
          </button>
        </li>
        <li>
          <button
            onClick={() => scrollToSection('portfolio')}
            className="text-[#e6f1ff] text-[0.95rem] hover:text-[#00f3ff] transition-colors"
          >
            Work
          </button>
        </li>
        <li>
          <button
            onClick={() => scrollToSection('contact')}
            className="btn-primary small"
          >
            Book Strategy
          </button>
        </li>
      </ul>

      {/* Mobile Menu Button */}
      <button
        className="md:hidden text-[#e6f1ff]"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      >
        {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="absolute top-full left-0 w-full glass-panel py-4 md:hidden">
          <ul className="flex flex-col items-center gap-4 list-none">
            <li>
              <button
                onClick={() => scrollToSection('services')}
                className="text-[#e6f1ff] hover:text-[#00f3ff] transition-colors"
              >
                Services
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection('process')}
                className="text-[#e6f1ff] hover:text-[#00f3ff] transition-colors"
              >
                Process
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection('portfolio')}
                className="text-[#e6f1ff] hover:text-[#00f3ff] transition-colors"
              >
                Work
              </button>
            </li>
            <li>
              <button
                onClick={() => scrollToSection('contact')}
                className="btn-primary small"
              >
                Book Strategy
              </button>
            </li>
          </ul>
        </div>
      )}
    </nav>
  );
}
