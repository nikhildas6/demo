import { useEffect, useRef, useState } from 'react';
import { Send, CheckCircle, Mail, User, Building, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const budgetOptions = [
  { value: '5k-10k', label: '$5,000 - $10,000' },
  { value: '10k-25k', label: '$10,000 - $25,000' },
  { value: '25k-50k', label: '$25,000 - $50,000' },
  { value: '50k+', label: '$50,000+' },
];

const serviceOptions = [
  { value: 'automation', label: 'AI Automation & Intelligent Agents' },
  { value: 'creative', label: 'AI Creative Studio' },
  { value: 'website', label: 'Intelligent Websites & SEO' },
  { value: 'multiple', label: 'Multiple Services' },
  { value: 'other', label: 'Other / Not Sure' },
];

export function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    service: '',
    budget: '',
    message: '',
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        email: '',
        company: '',
        service: '',
        budget: '',
        message: '',
      });
    }, 3000);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="min-h-screen flex flex-col items-center justify-center py-20 px-[5%] lg:px-[10%]"
      style={{
        background: 'linear-gradient(180deg, #0a192f 0%, #0d1f3a 100%)',
      }}
    >
      <div className="text-center mb-12 reveal">
        <h2 className="headline">
          Ready to <span className="text-gradient">Automate?</span>
        </h2>
        <p className="subheadline mx-auto">
          Book a free strategy session and discover how AI can transform your business.
        </p>
      </div>

      <div
        className="w-full max-w-2xl glass-card p-8 lg:p-12 reveal"
        style={{ transitionDelay: '200ms' }}
      >
        {isSubmitted ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <CheckCircle className="w-16 h-16 text-[#64ffda] mb-4" />
            <h3 className="text-2xl font-bold mb-2">Thank You!</h3>
            <p className="text-[#8892b0]">
              We've received your message and will get back to you within 24 hours.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="contact-form space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center gap-2 text-[#8892b0]">
                  <User className="w-4 h-4" /> Name *
                </Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="John Doe"
                  required
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="bg-[rgba(10,25,47,0.5)] border-[rgba(255,255,255,0.1)] text-white placeholder:text-[#4a5568] focus:border-[#00f3ff] focus:ring-[#00f3ff]/20"
                />
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2 text-[#8892b0]">
                  <Mail className="w-4 h-4" /> Email *
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@company.com"
                  required
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="bg-[rgba(10,25,47,0.5)] border-[rgba(255,255,255,0.1)] text-white placeholder:text-[#4a5568] focus:border-[#00f3ff] focus:ring-[#00f3ff]/20"
                />
              </div>

              {/* Company */}
              <div className="space-y-2">
                <Label htmlFor="company" className="flex items-center gap-2 text-[#8892b0]">
                  <Building className="w-4 h-4" /> Company
                </Label>
                <Input
                  id="company"
                  type="text"
                  placeholder="Your Company"
                  value={formData.company}
                  onChange={(e) => handleInputChange('company', e.target.value)}
                  className="bg-[rgba(10,25,47,0.5)] border-[rgba(255,255,255,0.1)] text-white placeholder:text-[#4a5568] focus:border-[#00f3ff] focus:ring-[#00f3ff]/20"
                />
              </div>

              {/* Service */}
              <div className="space-y-2">
                <Label htmlFor="service" className="text-[#8892b0]">
                  Service Interested In *
                </Label>
                <Select
                  required
                  value={formData.service}
                  onValueChange={(value) => handleInputChange('service', value)}
                >
                  <SelectTrigger className="bg-[rgba(10,25,47,0.5)] border-[rgba(255,255,255,0.1)] text-white focus:ring-[#00f3ff]/20">
                    <SelectValue placeholder="Select a service" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#112240] border-[rgba(255,255,255,0.1)]">
                    {serviceOptions.map((option) => (
                      <SelectItem
                        key={option.value}
                        value={option.value}
                        className="text-white hover:bg-[rgba(0,243,255,0.1)] focus:bg-[rgba(0,243,255,0.1)]"
                      >
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Budget */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="budget" className="text-[#8892b0]">
                  Estimated Budget
                </Label>
                <Select
                  value={formData.budget}
                  onValueChange={(value) => handleInputChange('budget', value)}
                >
                  <SelectTrigger className="bg-[rgba(10,25,47,0.5)] border-[rgba(255,255,255,0.1)] text-white focus:ring-[#00f3ff]/20">
                    <SelectValue placeholder="Select your budget range" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#112240] border-[rgba(255,255,255,0.1)]">
                    {budgetOptions.map((option) => (
                      <SelectItem
                        key={option.value}
                        value={option.value}
                        className="text-white hover:bg-[rgba(0,243,255,0.1)] focus:bg-[rgba(0,243,255,0.1)]"
                      >
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Message */}
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="message" className="flex items-center gap-2 text-[#8892b0]">
                  <MessageSquare className="w-4 h-4" /> Message *
                </Label>
                <Textarea
                  id="message"
                  placeholder="Tell us about your project and goals..."
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  className="bg-[rgba(10,25,47,0.5)] border-[rgba(255,255,255,0.1)] text-white placeholder:text-[#4a5568] focus:border-[#00f3ff] focus:ring-[#00f3ff]/20 resize-none"
                />
              </div>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              className="w-full btn-primary flex items-center justify-center gap-2 mt-4"
            >
              <Send className="w-4 h-4" />
              Book Strategy Session
            </Button>

            <p className="text-center text-sm text-[#8892b0] mt-4">
              We'll get back to you within 24 hours.
            </p>
          </form>
        )}
      </div>
    </section>
  );
}
