import { Mail, MapPin, Phone, Linkedin, Twitter, Github } from 'lucide-react';

const footerLinks = {
  services: [
    { label: 'AI Automation', href: '#services' },
    { label: 'AI Creative Studio', href: '#services' },
    { label: 'Intelligent Websites', href: '#services' },
  ],
  company: [
    { label: 'Our Process', href: '#process' },
    { label: 'Portfolio', href: '#portfolio' },
    { label: 'Contact', href: '#contact' },
  ],
};

export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id.replace('#', ''));
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#0a192f] border-t border-[rgba(255,255,255,0.1)] py-16 px-[5%] lg:px-[10%]">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="text-2xl font-bold tracking-wider mb-4">
              WHITECAP <span className="text-[#00f3ff]">AI</span>
            </div>
            <p className="text-[#8892b0] text-sm mb-6">
              Building intelligent automation systems that work 24/7. Replace work, not people.
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-[rgba(255,255,255,0.05)] flex items-center justify-center text-[#8892b0] hover:text-[#00f3ff] hover:bg-[rgba(0,243,255,0.1)] transition-all"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-[rgba(255,255,255,0.05)] flex items-center justify-center text-[#8892b0] hover:text-[#00f3ff] hover:bg-[rgba(0,243,255,0.1)] transition-all"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-[rgba(255,255,255,0.05)] flex items-center justify-center text-[#8892b0] hover:text-[#00f3ff] hover:bg-[rgba(0,243,255,0.1)] transition-all"
              >
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold mb-4">Services</h4>
            <ul className="space-y-3">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="text-[#8892b0] hover:text-[#00f3ff] transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="text-[#8892b0] hover:text-[#00f3ff] transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-[#8892b0] text-sm">
                <Mail className="w-4 h-4 text-[#00f3ff]" />
                hello@whitecap.ai
              </li>
              <li className="flex items-center gap-3 text-[#8892b0] text-sm">
                <Phone className="w-4 h-4 text-[#00f3ff]" />
                +1 (555) 123-4567
              </li>
              <li className="flex items-start gap-3 text-[#8892b0] text-sm">
                <MapPin className="w-4 h-4 text-[#00f3ff] mt-0.5" />
                San Francisco, CA
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[rgba(255,255,255,0.1)] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#8892b0] text-sm">
            © 2024 Whitecap AI. All rights reserved.
          </p>
          <div className="flex gap-6">
            <button className="text-[#8892b0] hover:text-[#00f3ff] transition-colors text-sm">
              Privacy Policy
            </button>
            <button className="text-[#8892b0] hover:text-[#00f3ff] transition-colors text-sm">
              Terms of Service
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
