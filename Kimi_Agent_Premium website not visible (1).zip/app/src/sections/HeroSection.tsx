import { useEffect, useRef } from 'react';
import { Bot, Palette, Rocket } from 'lucide-react';

export function HeroSection() {
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cards = cardsRef.current?.querySelectorAll('.glass-card');
    if (!cards) return;

    const handleMouseMove = (e: MouseEvent) => {
      cards.forEach((card) => {
        const rect = (card as HTMLElement).getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        (card as HTMLElement).style.transform = `
          perspective(1000px)
          rotateY(${x * 0.01}deg)
          rotateX(${-y * 0.01}deg)
          translateZ(10px)
        `;
      });
    };

    const handleMouseLeave = () => {
      cards.forEach((card) => {
        (card as HTMLElement).style.transform = 'perspective(1000px) rotateY(0) rotateX(0) translateZ(0)';
      });
    };

    const container = cardsRef.current;
    container?.addEventListener('mousemove', handleMouseMove);
    container?.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      container?.removeEventListener('mousemove', handleMouseMove);
      container?.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToProcess = () => {
    const element = document.getElementById('process');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="min-h-screen flex flex-col lg:flex-row items-center justify-between gap-12 pt-24 pb-12 px-[5%] lg:px-[10%]"
    >
      {/* Hero Content */}
      <div className="flex-1 z-10 max-w-2xl">
        <h1 className="headline animate-fade-in-up">
          Your Business Should{' '}
          <span className="text-gradient">Run Without You.</span>
        </h1>
        <p className="subheadline animate-fade-in-up delay-200">
          Whitecap AI builds intelligent automation systems, AI marketing engines,
          and high-performance websites that operate 24/7 — reducing cost and
          multiplying revenue.
        </p>
        <div className="flex flex-wrap gap-4 animate-fade-in-up delay-400">
          <button onClick={scrollToContact} className="btn-primary">
            Book Private Strategy Session
          </button>
          <button onClick={scrollToProcess} className="btn-secondary">
            See How It Works
          </button>
        </div>
      </div>

      {/* Hero Visual */}
      <div
        ref={cardsRef}
        className="flex-1 relative h-[400px] lg:h-[500px] flex justify-center items-center perspective-[1000px] hidden lg:flex"
      >
        {/* Card 1 - Main */}
        <div className="glass-card absolute w-[260px] z-10 animate-fade-in-up delay-300">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-full bg-[rgba(0,243,255,0.1)] flex items-center justify-center mb-4">
              <Bot className="w-8 h-8 text-[#00f3ff]" />
            </div>
            <h3 className="text-xl font-bold mb-2">AI Automation</h3>
            <p className="text-[#8892b0]">Intelligent Agents</p>
          </div>
        </div>

        {/* Card 2 - Floating */}
        <div className="glass-card absolute w-[220px] top-10 right-0 animate-fade-in-up delay-400 animate-float">
          <div className="flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-full bg-[rgba(100,255,218,0.1)] flex items-center justify-center mb-3">
              <Palette className="w-7 h-7 text-[#64ffda]" />
            </div>
            <h3 className="text-lg font-bold mb-1">AI Creative Studio</h3>
            <p className="text-[#8892b0] text-sm">Gen-AI Assets</p>
          </div>
        </div>

        {/* Card 3 - Floating */}
        <div
          className="glass-card absolute w-[220px] bottom-0 left-10 animate-fade-in-up delay-500"
          style={{ animation: 'fadeInUp 0.8s ease-out 0.5s forwards, float 6s ease-in-out 1s infinite' }}
        >
          <div className="flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-full bg-[rgba(0,243,255,0.1)] flex items-center justify-center mb-3">
              <Rocket className="w-7 h-7 text-[#00f3ff]" />
            </div>
            <h3 className="text-lg font-bold mb-1">AI SEO Systems</h3>
            <p className="text-[#8892b0] text-sm">Auto-Optimization</p>
          </div>
        </div>
      </div>
    </section>
  );
}
