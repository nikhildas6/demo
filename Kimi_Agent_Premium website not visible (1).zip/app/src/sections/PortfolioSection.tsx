import { useEffect, useRef } from 'react';
import { ExternalLink } from 'lucide-react';

const portfolioItems = [
  {
    title: 'E-Commerce AI Platform',
    category: 'AI Automation',
    description: 'Automated inventory & customer support system',
  },
  {
    title: 'Marketing Agency Dashboard',
    category: 'AI Creative Studio',
    description: 'AI-powered content generation & scheduling',
  },
  {
    title: 'SaaS Landing Page',
    category: 'Intelligent Websites',
    description: 'High-conversion AI-optimized website',
  },
  {
    title: 'Healthcare CRM System',
    category: 'AI Automation',
    description: 'Patient management & appointment automation',
  },
];

export function PortfolioSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="portfolio"
      className="min-h-screen flex flex-col items-center justify-center py-20 px-[5%] lg:px-[10%]"
      style={{ background: '#0a192f' }}
    >
      <div className="text-center mb-16 reveal">
        <h2 className="headline">
          Our <span className="text-gradient">Work</span>
        </h2>
        <p className="subheadline mx-auto">
          See how we've helped businesses transform with AI automation.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
        {portfolioItems.map((item, index) => (
          <div
            key={index}
            className="portfolio-item reveal"
            style={{ transitionDelay: `${(index + 1) * 150}ms` }}
          >
            {/* Placeholder gradient background */}
            <div
              className="w-full h-full"
              style={{
                background: `linear-gradient(135deg, #112240 0%, ${
                  index % 2 === 0 ? '#0d1f3a' : '#1a365d'
                } 100%)`,
              }}
            />
            
            {/* Overlay */}
            <div className="portfolio-overlay">
              <span className="text-[#00f3ff] text-sm font-medium mb-2">
                {item.category}
              </span>
              <h3 className="text-xl font-bold mb-2">{item.title}</h3>
              <p className="text-[#8892b0] text-sm mb-4">{item.description}</p>
              <button className="flex items-center gap-2 px-4 py-2 border border-white rounded-full text-sm hover:bg-white hover:text-[#0a192f] transition-all">
                View Project <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
