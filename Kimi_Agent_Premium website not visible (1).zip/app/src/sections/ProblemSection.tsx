import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';

const problems = [
  'Leads not followed up.',
  'Staff overloaded.',
  'Marketing inconsistent.',
  'Website not converting.',
  'Systems not connected.',
];

export function ProblemSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="problem"
      className="min-h-screen flex flex-col items-center justify-center py-20 px-[5%] lg:px-[10%]"
      style={{
        background: 'linear-gradient(180deg, #0a192f 0%, #0d1f3a 100%)',
      }}
    >
      <h2 className="headline text-center reveal">
        Manual Work Is <span className="text-alert">Killing Your Growth.</span>
      </h2>

      <div className="flex flex-wrap justify-center gap-6 lg:gap-8 mt-12 max-w-4xl">
        {problems.map((problem, index) => (
          <div
            key={index}
            className="flex items-center gap-3 text-lg lg:text-xl font-semibold text-[#cbd5e1] reveal"
            style={{ transitionDelay: `${(index + 1) * 100}ms` }}
          >
            <X className="w-6 h-6 text-[#ff4d4d] font-bold" strokeWidth={3} />
            <span>{problem}</span>
          </div>
        ))}
      </div>

      <div
        className="mt-16 text-xl lg:text-2xl font-bold text-center reveal"
        style={{ transitionDelay: '600ms' }}
      >
        <p>
          While you work harder…{' '}
          <span className="text-gradient">competitors automate smarter.</span>
        </p>
      </div>
    </section>
  );
}
