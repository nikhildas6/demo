import { useEffect, useRef } from 'react';

const steps = [
  {
    number: '01',
    title: 'Discovery',
    description: 'We analyze your workflows and identify automation opportunities.',
  },
  {
    number: '02',
    title: 'Strategy',
    description: 'We design a custom AI system architecture for your business.',
  },
  {
    number: '03',
    title: 'Build',
    description: 'We develop and integrate your intelligent automation systems.',
  },
  {
    number: '04',
    title: 'Launch',
    description: 'We deploy and optimize for maximum performance and ROI.',
  },
];

export function ProcessSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.2 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="process"
      className="min-h-screen flex flex-col items-center justify-center py-20 px-[5%] lg:px-[10%]"
      style={{
        background: 'linear-gradient(0deg, #0a192f 0%, #0d1f3a 100%)',
      }}
    >
      <div className="text-center mb-16 reveal">
        <h2 className="headline">
          Our <span className="text-gradient">Process</span>
        </h2>
        <p className="subheadline mx-auto">
          A proven methodology to transform your business with AI automation.
        </p>
      </div>

      {/* Desktop Timeline */}
      <div className="hidden lg:block relative max-w-5xl w-full">
        <div className="timeline-line" />
        <div className="flex justify-between items-start">
          {steps.map((step, index) => (
            <div
              key={index}
              className="timeline-step reveal"
              style={{ transitionDelay: `${(index + 1) * 150}ms` }}
            >
              <div className="step-number">{step.number}</div>
              <h3 className="text-lg font-bold mb-2 text-white">{step.title}</h3>
              <p className="text-sm text-[#8892b0] max-w-[200px]">{step.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Mobile Timeline */}
      <div className="lg:hidden flex flex-col gap-8 w-full max-w-md">
        {steps.map((step, index) => (
          <div
            key={index}
            className="flex items-center gap-6 reveal"
            style={{ transitionDelay: `${(index + 1) * 150}ms` }}
          >
            <div className="w-16 h-16 rounded-full bg-[#0a192f] border-2 border-[#00f3ff] flex items-center justify-center text-[#00f3ff] font-bold text-lg flex-shrink-0 shadow-[0_0_20px_rgba(0,243,255,0.2)]">
              {step.number}
            </div>
            <div>
              <h3 className="text-lg font-bold mb-1 text-white">{step.title}</h3>
              <p className="text-sm text-[#8892b0]">{step.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
