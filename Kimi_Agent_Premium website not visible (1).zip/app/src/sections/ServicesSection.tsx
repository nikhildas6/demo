import { useEffect, useRef } from 'react';
import { Bot, Palette, Zap } from 'lucide-react';

const services = [
  {
    icon: Bot,
    title: 'AI Automation & Intelligent Agents',
    features: [
      'CRM automation',
      'Lead qualification bots',
      'WhatsApp & Telegram AI agents',
      'Workflow automation',
      'Smart follow-up systems',
    ],
  },
  {
    icon: Palette,
    title: 'AI Creative Studio',
    features: [
      'AI-generated product posters',
      'AI commercial videos',
      'AI brand storytelling',
      'Social media AI campaigns',
    ],
  },
  {
    icon: Zap,
    title: 'Intelligent Websites & SEO',
    features: [
      'High-speed SEO-optimized websites',
      'AI-integrated chat systems',
      'Conversion architecture',
      'Structured data & AI indexing',
    ],
  },
];

export function ServicesSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = sectionRef.current?.querySelectorAll('.reveal');
    elements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="min-h-screen flex flex-col items-center justify-center py-20 px-[5%] lg:px-[10%]"
      style={{ background: '#0a192f' }}
    >
      <div className="text-center mb-16 reveal">
        <h2 className="headline">
          We Build AI Systems That{' '}
          <span className="text-gradient">Work 24/7.</span>
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full max-w-6xl">
        {services.map((service, index) => (
          <div
            key={index}
            className="service-card reveal"
            style={{ transitionDelay: `${(index + 1) * 150}ms` }}
          >
            <div className="card-glow" />
            <service.icon className="service-icon w-12 h-12 text-[#00f3ff]" />
            <h3 className="text-xl font-bold mb-6 text-white">{service.title}</h3>
            <ul className="service-list">
              {service.features.map((feature, fIndex) => (
                <li key={fIndex}>{feature}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
